package com.ecom.pojos;

public enum UserRole {

	ADMIN , CUSTOMER
}
